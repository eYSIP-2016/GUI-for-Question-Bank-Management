@extends('pages.layout')

#regardless of the order of sections in this file, the final sequence will adhere to that defined in the 
#layout file

@section('footer')
<h1>footer</h1>
@stop


@section('content')

<h1>hello world</h1>

@stop

