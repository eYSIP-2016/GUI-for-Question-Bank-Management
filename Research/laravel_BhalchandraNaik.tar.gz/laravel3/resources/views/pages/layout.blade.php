<!DOCTYPE html>
<html>
    <head>
    	<link rel="stylesheet" type="text/css" href="/css/style.css">
        <title>Laravel</title>
    </head>
    <body>
        @yield('content')
        <p>hello world my name is something</p>
        @yield('footer')
    </body>
</html>
