<?php $__env->startSection('content'); ?>
<?php foreach($cards as $card): ?>
 	<h1><?php echo e($card->title); ?></h1>
<?php endforeach; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>