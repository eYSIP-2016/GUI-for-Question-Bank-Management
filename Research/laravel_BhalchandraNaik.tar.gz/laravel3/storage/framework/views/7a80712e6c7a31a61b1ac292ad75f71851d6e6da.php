#regardless of the order of sections in this file, the final sequence will adhere to that defined in the 
#layout file

<?php $__env->startSection('footer'); ?>
<h1>footer</h1>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<h1>hello world</h1>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('pages.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>