<!DOCTYPE html>
<html>
    <head>
    	<link rel="stylesheet" type="text/css" href="/css/style.css">
        <title>Laravel</title>
    </head>
    <body>
        <?php echo $__env->yieldContent('content'); ?>
        <p>hello world my name is something</p>
        <?php echo $__env->yieldContent('footer'); ?>
    </body>
</html>
